module Rich
  module ApplicationHelper
  end
end
