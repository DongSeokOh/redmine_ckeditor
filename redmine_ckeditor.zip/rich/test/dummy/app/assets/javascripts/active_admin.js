//= require active_admin/base
//= require rich