require 'test_helper'

module Rich
  class FilesControllerTest < ActionController::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end
